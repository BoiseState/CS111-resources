#
# Project 2 - Deal some cards to the player
#
# author: krodgers <add your name>
#

# Import needed modules

import random



# Randomly deals cards to the user
# param: none
# return: number of new cards
def getCards():
    # Generate a random number between [0, 20]
    # Store the number in a variable called val
    
    # Create cards variable and set it to zero
    
    # if number < 10, set cards to 7 * val
    # else set cards to 3 * val

    # return cards




###########################################################
# Main - do not modify!                                   # 
# Sets the random seed and calls your function            #
# With the seed set, your output should match the example #
###########################################################

print("Testing getCards")
print()


random.seed(123)

cards = 0

# Deal cards three times
for i in range(3):
    print()
    print("Starting with " + str(cards) + " cards")
    cardsEarned = getCards()
    cards += cardsEarned
    print("I got " + str(cardsEarned))
    print("Now I have " + str(cards) + " cards")
    print()
