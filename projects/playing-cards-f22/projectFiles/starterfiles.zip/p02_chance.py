#
# Project 2 - Plays a round of chance
#
# author: krodgers <add your name>
#

# Import needed modules



# Generates a random number of cards to add to the player's hand.  It is possible
# that the player loses cards.
# return - number of cards dealt to player (if positive)
#          or the number of cards the player lost (if negative)
def chance():
    # Create a list to store the numbers

    # Use a for loop that iterates 10 times 
    #     generate a random number using random.randint
    #     add the random number to the list


    # Use a while loop: 
    #      Ask the user for three numbers
    #      store the user's numbers in idx1, idx2, and idx3, respectively
    #      Check that each number is between 0 and 9
    #      If all three numbers are valid, the loop should end
    #      Otherwise, tell the user one of their numbers was invalid

    # (after the while loop)
    # Use idx1 to get and store the element store in the list at idx1
    
    # Use idx2 to get and store the element store in the list at idx2

    # Use idx3 to get and store the element store in the list at idx3

    # Compute and store the sum of the three elements
    
    # Show the user what values they chose and the total sum
    # You picked x, y, and z for a total of w cards
    
    # return the total sum










###########################################################
# Main - don't modify                                     #
# Sets the random seed and calls your function            #
# With the seed set, your output should match the example #
###########################################################
from io import StringIO
import sys


print("Testing chance - automated input")
print()

testInput = ["0\n3\n6\n", "4\n8\n9\n", "1\n-2\n5\n100\n4\n5\n10\n20\n30\n0\n9\n2\n"]
seeds = [3, 200, 956]
originalIn = sys.stdin
try:
    for i in range(len(seeds)):
        random.seed(seeds[i])
        inputs = StringIO(testInput[i])
        sys.stdin = inputs
        earned = chance()
        print("You earned " + str(earned) + " more cards")
        print()
except Exception as e:
    print(e)
    print("Something went wrong")
    
finally:
    sys.stdin = originalIn

    
