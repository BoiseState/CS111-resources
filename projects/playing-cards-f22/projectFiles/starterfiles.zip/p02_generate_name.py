#
# Project 2 - Generate a Random Name
#
# author: krodgers <add your name>
#

# Import needed modules (if any)



# Generates a random name in the form Emotion Shape
# param: emotionList, list of Strings containing 5 different emotions
#        shapeList, list of Strings containing 5 different shapes
# return: generated name
def generateName(emotionList, shapeList):
    # Randomly choose (and store) a element from emotionList

    # Randomly choose (and store) an element from shapeList

    # Create the name by concatenating the chosen elements
    # Don't forget to put a space between the emotion and the shape!
    
    # Return the created name

    





###########################################################################
# Main - do not modify!                                                   #
# Tests your function                                                     #
# Will automatically provide input to your function, except the first call #
###########################################################################

emotions = ["Annoyed", "Offended", "Contented"]
shapes = ["Rhombus", "Pyramid", "Heptagon"]



seeds = [3, 16, 24]
expected = ["Annoyed Heptagon", "Offended Pyramid", "Contented Pyramid"]
for i in range(len(seeds)):
    random.seed(seeds[i])
    name = generateName(emotions, shapes)
    print("Name generated: " + name)
    print("Expected name: " + expected[i])
    print()



